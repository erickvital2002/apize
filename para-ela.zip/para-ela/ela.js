function sim(){
    alert("você aceitou voltar comigo!Agora clique em OK :)")
}




    function moveButton(x) {
        marginX = Math.floor(Math.random()*600)
        marginY = Math.floor(Math.random()*600)

        x.style.margin = marginY.toString() + 'px ' + marginX.toString() + 'px'
    }













